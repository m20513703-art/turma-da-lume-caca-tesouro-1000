Turma da Lume — Caça ao Tesouro

Android WebView wrapper for ../edition-1000. Build with `gradle assembleRelease`.
The release APK is debug-signed; the signing key is local to the build runner, so this is for testing/installation, not a Play Store production signing identity.
