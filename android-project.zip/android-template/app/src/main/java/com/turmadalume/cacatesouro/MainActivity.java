package com.turmadalume.cacatesouro;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    Window w=getWindow(); w.setStatusBarColor(Color.rgb(24,60,49)); w.setNavigationBarColor(Color.rgb(24,60,49));
    WebView web=new WebView(this); web.setBackgroundColor(Color.rgb(24,60,49));
    WebSettings settings=web.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setAllowFileAccess(true); settings.setLoadsImagesAutomatically(true); settings.setDefaultTextEncodingName("UTF-8");
    web.setWebViewClient(new WebViewClient()); setContentView(web); web.loadUrl("file:///android_asset/www/index.html");
  }
  @Override public void onBackPressed() { new android.app.AlertDialog.Builder(this).setMessage("Quer sair do jogo?").setNegativeButton("Continuar",(d,w)->d.dismiss()).setPositiveButton("Sair",(d,w)->finish()).show(); }
}
